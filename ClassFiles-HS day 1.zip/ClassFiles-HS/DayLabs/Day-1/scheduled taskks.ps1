﻿get-help New-ScheduledTaskSettingsSet -Full
get-help New-ScheduledTaskSettingsSet -ShowWindow